// pages/protected.tsx
import withAuth from '../context/withAuth';

const ProtectedPage = () => {
    return <h1>This is a protected page!</h1>;
};

export default withAuth(ProtectedPage);
