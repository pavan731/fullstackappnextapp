// context/withAuth.tsx
import { useAuth } from './AuthContext';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

const withAuth = (WrappedComponent: React.FC) => {
    const AuthHOC = (props: any) => {
        const { isAuthenticated } = useAuth(); // Use the boolean value from AuthContext
        const router = useRouter();

        useEffect(() => {
            if (!isAuthenticated) {
                router.push('/login'); // Redirect to login if not authenticated
            }
        }, [isAuthenticated, router]);

        // If the user is authenticated, render the wrapped component
        // Otherwise, return null (or a loading spinner)
        return isAuthenticated ? <WrappedComponent {...props} /> : null;
    };

    return AuthHOC;
};

export default withAuth;
