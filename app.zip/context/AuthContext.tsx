// abc/frontend/context/AuthContext.tsx
"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import Cookies from 'js-cookie';

interface AuthContextProps {
    isAuthenticated: boolean;
    user: { name: string } | null; // Define user type here
    login: (token: string, userData: { name: string }) => void; // Accept user data in login
    logout: () => void;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [user, setUser] = useState<{ name: string } | null>(null); // Manage user state

    useEffect(() => {
        const token = Cookies.get('authToken');
        if (token) {
            setIsAuthenticated(true);
            // Optionally, you could fetch user details from your backend here
            setUser({ name: 'John Doe' }); // Mocking user data
        }
    }, []);

    const login = (token: string, userData: { name: string }) => {
        Cookies.set('authToken', token);
        setIsAuthenticated(true);
        setUser(userData); // Set user data on login
    };

    const logout = () => {
        Cookies.remove('authToken');
        setIsAuthenticated(false);
        setUser(null); // Clear user data on logout
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
