// abc/frontend/app/layout.tsx
import React, { ReactNode } from 'react';
import { AuthProvider } from '../context/AuthContext';

interface Props {
    children: ReactNode; // Explicitly define the type of children
}

export default function RootLayout({ children }: Props) {
    return (
        <AuthProvider>
            <html lang="en">
                <body>{children}</body>
            </html>
        </AuthProvider>
    );
}
