// abc/frontend/app/components/Header.tsx
"use client";

import { useRouter } from 'next/navigation';
import { useAuth } from '../../context/AuthContext'; 
import Cookies from 'js-cookie';

const Header = () => {
    const { isAuthenticated, user, logout } = useAuth(); 
    const router = useRouter(); 

    const handleLogout = () => {
        logout(); // Call logout from context to clear user state
        router.push('/login'); // Redirect to login page after logout
    };

    if (!isAuthenticated) {
        return null; // Render nothing if the user is not authenticated
    }

    return (
        <header style={{
            backgroundColor: '#f5f5f5',
            padding: '10px 20px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            borderBottom: '1px solid #ddd'
        }}>
            <h1>My Application</h1>
            <div style={{ display: 'flex', alignItems: 'center' }}>
                {user && <p style={{ margin: '0 10px' }}>Welcome, {user.name}</p>}
                <button
                    onClick={handleLogout}
                    style={{
                        padding: '8px 12px',
                        backgroundColor: '#ff4d4d',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer'
                    }}
                >
                    Logout
                </button>
            </div>
        </header>
    );
};

export default Header;
