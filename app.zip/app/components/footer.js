// abc/frontend/app/components/Footer.tsx
const Footer = () => {
    return (
        <footer style={{ backgroundColor: '#f5f5f5', padding: '10px 20px', textAlign: 'center', position: 'fixed', bottom: 0, width: '100%' }}>
            <p>&copy; 2024 My Application. All rights reserved.</p>
        </footer>
    );
};

export default Footer;
