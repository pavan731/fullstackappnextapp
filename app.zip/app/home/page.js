// abc/frontend/app/home/page.tsx
"use client"; // This line marks the component as a Client Component

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation'; // Use next/navigation for app directory
import { useAuth } from '../../context/AuthContext'; // Import AuthContext from the context folder
import Header from '../components/Header'; // Import the Header component
import Footer from '../components/Footer'; // Import the Footer component

const HomePage = () => {
    const { isAuthenticated } = useAuth(); // Get the authentication status from AuthContext
    const router = useRouter(); // Next.js router for navigation
    const [isMounted, setIsMounted] = useState(false); // State to check if component has mounted

    useEffect(() => {
        // Set the mounted state to true after the component has mounted
        setIsMounted(true);
    }, []);

    useEffect(() => {
        // If the user is not authenticated, redirect to the login page
        if (isMounted && !isAuthenticated) {
            router.push('/login');
        }
    }, [isMounted, isAuthenticated, router]);

    if (!isMounted || !isAuthenticated) {
        return null; // Optionally, render a loading indicator while redirecting
    }

    return (
        <div style={{ paddingTop: '1px', paddingBottom: '1px' }}>
            <Header />
            <main style={{ minHeight: '100vh', textAlign: 'center' }}>
                <h1>Welcome to the Home Page</h1>
                <p>This is a protected route. Only authenticated users can access this content.</p>
            </main>
            <Footer />
        </div>
    );
};

export default HomePage;
