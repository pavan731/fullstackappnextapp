// pages/register.tsx
import { useState } from 'react';
import axios from 'axios';
import qs from 'qs';

const Register = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            // Use qs to stringify the data into x-www-form-urlencoded format
            const data = qs.stringify({
                email,
                password,
            });

            await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/register`, data, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            });

            // Redirect to login or show a success message
            console.log('Registration successful!');
        } catch (error) {
            console.error('Registration failed:', error);
            // Handle error
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
            />
            <button type="submit">Register</button>
        </form>
    );
};

export default Register;
