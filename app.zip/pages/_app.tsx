// abc/frontend/pages/_app.tsx
import { AuthProvider } from '../context/AuthContext'; // Import AuthProvider from context
import '../styles/globals.css'; // Import global styles

import { AppProps } from 'next/app'; // Import AppProps from next/app

function MyApp({ Component, pageProps }: AppProps) {
    return (
        <AuthProvider> {/* Wrap the component with AuthProvider */}
            <Component {...pageProps} />
        </AuthProvider>
    );
}

export default MyApp;
